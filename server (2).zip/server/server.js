const express = require('express');
const mongoose = require('mongoose');
const petRouter = require('./routes/pets'); // Adjust the path as needed

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json()); // Middleware to parse JSON bodies

// Use the pet router for /api/pets route
app.use('/api/pets', petRouter);

mongoose.connect('mongodb://localhost:27017/pet_app_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

