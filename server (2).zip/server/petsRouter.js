const express = require('express');
const router = express.Router();
const Pet = require('./pet'); 

// GET /pets - Get all pets
router.get('/', async (req, res) => {
  try {
    const pets = await Pet.find();
    res.json(pets);
  } catch (err) {
    console.error(err); // Log the error for debugging
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /pets/:id - Get a specific pet by ID
router.get('/:id', async (req, res) => {
  try {
    const pet = await Pet.findById(req.params.id);
    if (!pet) {
      return res.status(404).json({ error: 'Pet not found' });
    }
    res.json(pet);
  } catch (err) {
    console.error(err); // Log the error for debugging
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /pets - Create a new pet
router.post('/', async (req, res) => {
  try {
    const newPet = new Pet(req.body);
    const result = await newPet.save();
    res.status(201).json(result); // Send the created pet object as response
  } catch (err) {
    console.error(err); // Log the error for debugging
    if (err.code === 11000) {
      res.status(400).json({ error: 'Duplicate key error' });
    } else {
      res.status(500).json({ error: 'Internal server error' });
    }
  }
});

// PUT /pets/:id - Update a pet by ID
router.put('/:id', async (req, res) => {
  try {
    const pet = await Pet.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!pet) {
      return res.status(404).json({ error: 'Pet not found' });
    }
    res.json(pet);
  } catch (err) {
    console.error(err); // Log the error for debugging
    res.status(400).json({ error: 'Invalid request' });
  }
});

// DELETE /pets/:id - Delete a pet by ID
router.delete('/:id', async (req, res) => {
  try {
    const pet = await Pet.findByIdAndDelete(req.params.id);
    if (!pet) {
      return res.status(404).json({ error: 'Pet not found' });
    }
    res.status(204).end(); // No content to return
  } catch (err) {
    console.error(err); // Log the error for debugging
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;

