const mongoose = require('mongoose');

const petSchema = new mongoose.Schema({
  name: { type: String, required: true },
  breed: { type: String, required: true },
  age: { type: Number, required: true },
  notes: { type: String } // Optional field
});

module.exports = mongoose.model('Pet', petSchema);
