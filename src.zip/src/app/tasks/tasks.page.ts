import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from '../task.service';
import { Task } from '../interfaces/task.interface';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-task-list',
  templateUrl: 'tasks.page.html',
  styleUrls: ['tasks.page.scss'],
})
export class TaskListPage implements OnInit {
  tasks$: Observable<Task[]> = new Observable<Task[]>();

  constructor(private taskService: TaskService, private router: Router) {}

  ngOnInit() {
    this.tasks$ = this.taskService.getTasks();
  }

  navigateToTaskDetails(task: Task) {
    if (task.id) {
      this.router.navigate(['/task-details', task.id]);
    } else {
      console.error('Task ID is missing');
    }
  }

  toggleTaskCompletion(task: Task) {
    if (task.id) {
      const updatedTask: Task = {
        ...task,
        completed: !task.completed
      };

      this.taskService.updateTask(task.id, updatedTask).subscribe(
        () => {
          task.completed = !task.completed;
        },
        error => {
          console.error('Error updating task', error);
        }
      );
    } else {
      console.error('Task ID is missing');
    }
  }
}



