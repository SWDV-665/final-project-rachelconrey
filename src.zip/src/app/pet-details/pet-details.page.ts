import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PetService } from '../pet.service';
import { Pet } from '../interfaces/pet.interface';

@Component({
  selector: 'app-pet-details',
  templateUrl: './pet-details.page.html',
  styleUrls: ['./pet-details.page.scss'],
})
export class PetDetailsPage implements OnInit {
  pet: Pet | null = null;

  constructor(
    private route: ActivatedRoute,
    private petService: PetService,
    private router: Router
  ) {}

  ngOnInit() {
    const petId = this.route.snapshot.paramMap.get('id');
    if (petId) {
      this.petService.getPets().subscribe(
        (pets: Pet[]) => {
          this.pet = pets[0]; 
        },
        error => {
          console.error('Error fetching pet details', error);
        }
      );
    } else {
      console.error('No pet ID found in route');
      this.router.navigate(['/pets']);
    }
  }
  editPet() {
    console.log('Edit pet button clicked');
    // Add logic to handle pet editing
  }
}
