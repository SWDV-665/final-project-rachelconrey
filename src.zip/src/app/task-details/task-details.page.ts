import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../task.service';
import { Task } from '../interfaces/task.interface';

@Component({
  selector: 'app-task-details',
  templateUrl: 'task-details.page.html',
  styleUrls: ['task-details.page.scss'],
})
export class TaskDetailsPage implements OnInit {
  task: Task | null = null;

  constructor(
    private route: ActivatedRoute,
    private taskService: TaskService,
    private router: Router
  ) {}

  ngOnInit() {
    const taskId = this.route.snapshot.paramMap.get('id');
    if (taskId) {
      this.taskService.getTask(taskId).subscribe(
        (task: Task) => {
          this.task = task;
        },
        error => {
          console.error('Error fetching task details', error);
        }
      );
    } else {
      console.error('No task ID found in route');
      this.router.navigate(['/task-list']);
    }
  }

  saveTask() {
    if (this.task && this.task.id) {
      this.taskService.updateTask(this.task.id, this.task).subscribe(
        () => {
          this.router.navigate(['/task-list']);
        },
        error => {
          console.error('Error updating task', error);
        }
      );
    } else {
      console.error('No task or task ID to save');
    }
  }
}



