import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PetService } from '../pet.service';
import { Pet } from '../interfaces/pet.interface';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-pet-profile',
  templateUrl: 'pets.page.html',
  styleUrls: ['pets.page.scss'],
})
export class PetProfilePage implements OnInit {
  pets$: Observable<Pet[]> = new Observable<Pet[]>();
  showForm = false;
  isEditing = false; // Track if editing a pet
  newPet: Pet = { id: '', name: '', breed: '', age: 0 };
  currentPetId: string | null = null; // Track the ID of the pet being edited

  constructor(private petService: PetService, private router: Router) {}

  ngOnInit() {
    this.pets$ = this.petService.getPets(); // Fetch pets as an observable
  }

  navigateToPetDetails(pet: Pet) {
    if (pet.id) {
      this.router.navigate(['/pet-details', pet.id]);
    } else {
      console.error('Pet ID is undefined');
    }
  }

  addPet() {
    this.showForm = true;  // Show the form
    this.isEditing = false;
    this.resetForm();
  }

  editPet(pet: Pet) {
    this.showForm = true; // Show the form
    this.isEditing = true;
    this.newPet = { ...pet }; // Populate the form with the pet data
    this.currentPetId = pet.id; // Set the ID of the pet being edited
  }

  savePet() {
    if (this.isEditing && this.currentPetId) {
      // Update existing pet
      this.petService.updatePet(this.currentPetId, this.newPet).subscribe({
        next: () => {
          this.pets$ = this.petService.getPets(); // Refresh the pet list
          this.resetForm();
          this.showForm = false;
          this.isEditing = false;
        },
        error: (err) => console.error('Update failed', err),
      });
    } else {
      // Add new pet
      this.petService.addPet(this.newPet).subscribe({
        next: () => {
          this.pets$ = this.petService.getPets(); // Refresh the pet list
          this.resetForm();
          this.showForm = false;
        },
        error: (err) => console.error('Add failed', err),
      });
    }
  }

  deletePet(petId: string) {
    this.petService.deletePet(petId).subscribe({
      next: () => {
        this.pets$ = this.petService.getPets(); // Refresh the pet list
      },
      error: (err) => console.error('Delete failed', err),
    });
  }

  cancel() {
    this.resetForm();
    this.showForm = false;
  }

  resetForm() {
    this.newPet = { id: '', name: '', breed: '', age: 0 };
    this.currentPetId = null;
  }
}




