import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TaskListPage } from './tasks/tasks.page';
import { PetProfilePage } from './pets/pets.page';
import { TaskDetailsPage } from './task-details/task-details.page';

const routes: Routes = [
  { path: '', redirectTo: 'pets', pathMatch: 'full' },
  { path: 'tasks', component: TaskListPage },
  { path: 'pets', component: PetProfilePage },
  { path: 'task-details/:id', component: TaskDetailsPage },
  { path: '**', redirectTo: 'pets', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

