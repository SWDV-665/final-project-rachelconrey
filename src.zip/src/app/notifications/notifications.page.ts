import { Component } from '@angular/core';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(private localNotifications: LocalNotifications) {
    this.initializeApp();
  }

  initializeApp() {
    this.localNotifications.on('click').subscribe(notification => {
      console.log('Notification clicked:', notification);
    });
  }

  // Schedule a daily reminder
  scheduleDailyReminder() {
    this.localNotifications.schedule({
      id: 1,
      title: 'Pet Feeding Reminder',
      text: 'Don’t forget to feed your pet!',
      trigger: {
        every: {
          hour: 8,  // Trigger at 8 AM daily
          minute: 0,
        }
      },
      sound: 'file://sound.mp3'
    });
  }
}



